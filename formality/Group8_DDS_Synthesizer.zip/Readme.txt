- Used both Conformal and Formality to solve bugs in one file.
- File Structure
	- Synthesized File
	- Solved Bugs File

- Group 8
- Group members: Balaji Ravindaran, Nitish Sundarraj

- Contact: b_ravin@live.concordia.ca; ni_sunda@live.concordia.ca
